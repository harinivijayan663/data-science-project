import numpy as np
import pandas as pd
import os

def generate_student_data(n_samples=200):
    """
    Generate realistic student data with various features.
    
    Parameters:
    -----------
    n_samples : int
        Number of student records to generate
        
    Returns:
    --------
    pandas.DataFrame
        DataFrame containing student data
    """
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate features
    study_hours = np.random.normal(7, 2, n_samples)  # Mean of 7 hours, std of 2
    study_hours = np.clip(study_hours, 0, 12)  # Clip between 0 and 12 hours
    
    attendance = np.random.normal(85, 10, n_samples)  # Mean of 85%, std of 10%
    attendance = np.clip(attendance, 0, 100)
    
    assignments = np.random.normal(78, 15, n_samples)  # Mean of 78%, std of 15%
    assignments = np.clip(assignments, 0, 100)
    
    midterm_score = np.random.normal(75, 12, n_samples)
    midterm_score = np.clip(midterm_score, 0, 100)
    
    # Create some correlation between features and final score
    base_score = (0.3 * study_hours/12 + 
                 0.2 * attendance/100 + 
                 0.25 * assignments/100 +
                 0.25 * midterm_score/100)
    
    # Add some noise to final score
    noise = np.random.normal(0, 0.1, n_samples)
    final_score = (base_score + noise) * 100
    final_score = np.clip(final_score, 0, 100)
    
    # Create DataFrame
    data = pd.DataFrame({
        'study_hours': np.round(study_hours, 2),
        'attendance': np.round(attendance, 2),
        'assignments': np.round(assignments, 2),
        'midterm_score': np.round(midterm_score, 2),
        'final_score': np.round(final_score, 2)
    })
    
    return data

def main():
    # Create data directory if it doesn't exist
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    os.makedirs(data_dir, exist_ok=True)
    
    # Generate data
    print("Generating student data...")
    data = generate_student_data()
    
    # Save to CSV
    output_path = os.path.join(data_dir, 'student_data.csv')
    data.to_csv(output_path, index=False)
    print(f"Data saved to {output_path}")
    print(f"Generated {len(data)} student records")
    
    # Display sample statistics
    print("\nData Summary:")
    print(data.describe().round(2))

if __name__ == "__main__":
    main()