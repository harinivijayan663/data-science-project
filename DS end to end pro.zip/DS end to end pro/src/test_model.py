import unittest
import pandas as pd
import numpy as np
import os
from data_generator import generate_student_data
from train import load_and_preprocess_data, train_model

class TestStudentPerformancePredictor(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Get project root directory
        cls.root_dir = os.path.dirname(os.path.dirname(__file__))
        
        # Create data directory if it doesn't exist
        data_dir = os.path.join(cls.root_dir, 'data')
        os.makedirs(data_dir, exist_ok=True)
        
        # Generate test data
        cls.test_data = generate_student_data(n_samples=100)
        test_data_path = os.path.join(data_dir, 'test_data.csv')
        cls.test_data.to_csv(test_data_path, index=False)
        cls.test_data_path = test_data_path
        
    def test_data_generation(self):
        """Test if generated data is within expected ranges"""
        self.assertEqual(len(self.test_data), 100)
        self.assertTrue(all(0 <= self.test_data['study_hours']) and all(self.test_data['study_hours'] <= 12))
        self.assertTrue(all(0 <= self.test_data['attendance']) and all(self.test_data['attendance'] <= 100))
        self.assertTrue(all(0 <= self.test_data['final_score']) and all(self.test_data['final_score'] <= 100))
    
    def test_model_training(self):
        """Test if model training works and produces reasonable results"""
        X, y, feature_names, scaler = load_and_preprocess_data(self.test_data_path)
        model, metrics = train_model(X, y)
        
        # Check if model performance is reasonable (R² > 0.5)
        self.assertGreater(metrics['r2'], 0.5)
        
        # Test prediction on sample data
        sample_input = np.array([[8, 90, 85, 88]])  # Good student
        sample_scaled = scaler.transform(sample_input)
        prediction = model.predict(sample_scaled)[0]
        
        # Prediction should be between 0 and 100
        self.assertTrue(0 <= prediction <= 100)

if __name__ == '__main__':
    unittest.main()