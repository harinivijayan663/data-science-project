import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import os

def load_and_preprocess_data(data_path):
    """
    Load and preprocess the student data.
    
    Parameters:
    -----------
    data_path : str
        Path to the CSV file containing student data
        
    Returns:
    --------
    X : array-like
        Feature matrix
    y : array-like
        Target variable
    feature_names : list
        List of feature names
    scaler : StandardScaler
        Fitted scaler object for feature normalization
    """
    # Load data
    data = pd.read_csv(data_path)
    
    # Separate features and target
    feature_names = ['study_hours', 'attendance', 'assignments', 'midterm_score']
    X = data[feature_names]
    y = data['final_score']
    
    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    return X_scaled, y, feature_names, scaler

def train_model(X, y):
    """
    Train a regression model on the data.
    
    Parameters:
    -----------
    X : array-like
        Feature matrix
    y : array-like
        Target variable
        
    Returns:
    --------
    model : sklearn estimator
        Trained model
    metrics : dict
        Dictionary containing performance metrics
    """
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Train model
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    
    metrics = {
        'mse': mse,
        'rmse': np.sqrt(mse),
        'r2': r2
    }
    
    return model, metrics

def main():
    # Get project root directory
    root_dir = os.path.dirname(os.path.dirname(__file__))
    
    # Create models directory if it doesn't exist
    models_dir = os.path.join(root_dir, 'models')
    os.makedirs(models_dir, exist_ok=True)
    
    # Load and preprocess data
    print("Loading and preprocessing data...")
    data_path = os.path.join(root_dir, 'data', 'student_data.csv')
    X, y, feature_names, scaler = load_and_preprocess_data(data_path)
    
    # Train model
    print("Training model...")
    model, metrics = train_model(X, y)
    
    # Save model and scaler
    print("Saving model and scaler...")
    model_path = os.path.join(models_dir, 'model.joblib')
    scaler_path = os.path.join(models_dir, 'scaler.joblib')
    
    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)
    
    # Print metrics
    print("\nModel Performance:")
    print(f"R² Score: {metrics['r2']:.4f}")
    print(f"RMSE: {metrics['rmse']:.4f}")
    print(f"MSE: {metrics['mse']:.4f}")
    
    # Print feature importance
    importance = pd.DataFrame({
        'feature': feature_names,
        'importance': np.abs(model.coef_)
    })
    print("\nFeature Importance:")
    print(importance.sort_values('importance', ascending=False))

if __name__ == "__main__":
    main()