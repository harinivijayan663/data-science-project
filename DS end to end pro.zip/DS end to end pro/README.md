# Student Performance Predictor

A professional web application that predicts student performance based on various input features like study hours, attendance, and assignment scores.

## Project Structure

```
.
├── data/               # Data directory
│   └── student_data.csv    # Student dataset
├── models/            # Trained models directory
│   └── model.joblib       # Saved model file
├── notebooks/         # Jupyter notebooks for EDA
│   └── analysis.ipynb    # Data analysis notebook
├── src/              # Source code
│   ├── data_generator.py # Script to generate sample data
│   └── train.py         # Model training script
└── webapp/           # Flask web application
    ├── static/          # Static files (CSS, JS)
    ├── templates/       # HTML templates
    └── app.py          # Flask application
```

## Features

- Data collection from CSV file
- Exploratory Data Analysis (EDA)
- Machine Learning model training and evaluation
- Professional web interface for predictions
- Local deployment using Flask

## Setup and Installation

1. Clone this repository
2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Generate sample data:
   ```bash
   python src/data_generator.py
   ```

2. Train the model:
   ```bash
   python src/train.py
   ```

3. Run the web application:
   ```bash
   python webapp/app.py
   ```

4. Open your browser and navigate to `http://localhost:5000`

## Project Components

1. **Data Generation**: Creates realistic student data including study hours, attendance, assignments scores, etc.
2. **Model Training**: Preprocesses data and trains a regression model to predict final scores
3. **Web Application**: Clean, professional interface for making predictions
4. **Documentation**: Comprehensive documentation and setup instructions