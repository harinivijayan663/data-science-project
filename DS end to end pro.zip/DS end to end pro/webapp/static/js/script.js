document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('prediction-form');
    const result = document.getElementById('result');
    const errorMessage = document.getElementById('error-message');
    const predictionValue = document.getElementById('prediction-value');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Hide any previous results or errors
        result.classList.add('hidden');
        errorMessage.classList.add('hidden');
        
        // Get form data
        const formData = new FormData(form);
        
        // Send prediction request
        fetch('/predict', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show prediction
                predictionValue.textContent = `${data.prediction}/100`;
                result.classList.remove('hidden');
            } else {
                // Show error
                errorMessage.classList.remove('hidden');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            errorMessage.classList.remove('hidden');
        });
    });

    // Add input validation
    const inputs = form.querySelectorAll('input[type="number"]');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            const value = parseFloat(this.value);
            const min = parseFloat(this.min);
            const max = parseFloat(this.max);
            
            if (value < min) this.value = min;
            if (value > max) this.value = max;
        });
    });
});